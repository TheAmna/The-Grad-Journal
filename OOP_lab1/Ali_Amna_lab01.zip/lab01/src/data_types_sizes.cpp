#include<iostream>
using namespace std;

int main(){
    cout << "The size of char is : "<< sizeof(char)<< " bytes\n" ;
    cout << "The size of int is : "<< sizeof(int)<< " bytes\n" ;
    cout << "The size of float is : "<< sizeof(float)<< " bytes\n" ;
    cout << "The size of double is : "<< sizeof(double)<< " bytes\n" ;
    cout << "The size of long is : "<< sizeof(long)<< " bytes\n" ;
    cout << "The size of short is : "<< sizeof(short)<< " bytes\n" ;
    cout << "The size of bool is : "<< sizeof(bool)<< " bytes\n" ;
    return 0;
}