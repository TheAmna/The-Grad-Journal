#include<iostream>
using namespace std;

int main(){
    char a;
    cout << "Enter a lowercase character : " ;
    cin >> a ;
    char b = a -32;
    cout <<  b;
    return 0;
}